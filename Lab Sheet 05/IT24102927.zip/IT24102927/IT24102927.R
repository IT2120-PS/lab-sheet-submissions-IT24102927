# 1. Import the dataset into R
setwd("C:\\Users\\it24102927\\Desktop\\IT24102927")
getwd()
Delivery.Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep=" ")
Delivery.Times

# 2. Draw a histogram for delivery times
hist(Delivery.Times$Delivery, breaks = seq(20, 70, by = 5), right = TRUE, 
     main = "Histogram of Delivery Times", 
     xlab = "Delivery Times", 
     ylab = "Frequency")

# 3. Comment on the shape of the distribution
# For this, you will need to manually assess the shape of the histogram.

# 4. Draw a cumulative frequency polygon (Ogive)
cumulative_freq <- cumsum(table(cut(Delivery.Times$Delivery, breaks = seq(20, 70, by = 5), right = TRUE)))
plot(seq(22.5, 67.5, by = 5), cumulative_freq, 
     type = "o", 
     main = "Cumulative Frequency Polygon (Ogive)", 
     xlab = "Delivery Times", 
     ylab = "Cumulative Frequency", 
     pch = 16)
